const root = document.getElementById("root");

let battles = [];

function render() {
  root.innerHTML = `
    <h1>Sky Veil Faction Battles</h1>
    <p>Post or accept 6v6 challenges</p>
    <form id="battleForm">
      <input name="faction" placeholder="Your Faction Name" required /><br/>
      <input name="contact" placeholder="Contact Info (Discord)" required /><br/>
      <input name="date" type="datetime-local" required /><br/>
      <textarea name="message" placeholder="Notes (Optional)"></textarea><br/>
      <button type="submit">Post Battle Request</button>
    </form>
    <h2>Open Battle Requests</h2>
    ${battles.map(b => `
      <div class="card">
        <h3>${b.faction}</h3>
        <p><strong>Contact:</strong> ${b.contact}</p>
        <p><strong>Date:</strong> ${new Date(b.date).toLocaleString()}</p>
        ${b.message ? `<p><em>${b.message}</em></p>` : ""}
      </div>
    `).join("")}
  `;

  document.getElementById("battleForm").onsubmit = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target).entries());
    battles.push(data);
    e.target.reset();
    render();
  };
}

render();
